
const KB_URL = 'faqs.json';
const state = { kb: [], opened: false };
function el(q){ return document.querySelector(q) }
function createMsg(text, who='bot'){
  const wrap = document.createElement('div'); wrap.className = 'msg ' + who;
  const bubble = document.createElement('div'); bubble.className = 'bubble'; bubble.textContent = text;
  wrap.appendChild(bubble);
  return wrap;
}
async function loadKB(){
  if(state.kb.length) return;
  const res = await fetch(KB_URL);
  state.kb = await res.json();
}
function bestAnswer(q){
  q = q.toLowerCase();
  const intents = [
    {keys:['حساب','انشاء','تسجيل'], ans:'حتى تبدي، سوّي حساب جديد من الصفحة الرئيسية: الاسم، رقم الهاتف، كلمة السر. بعدها تقدر تبيع فوراً.'},
    {keys:['سحب','ارباح','زين','حوالة','ماستر','رافدين'], ans:'سحب الأرباح من (حسابي ← سحب الأرباح) وتختار الطريقة: زين كاش، آسيا حوالة، رصيد زين/آسيا سيل، ماستر كارد الرافدين، أو التحويل البنكي المتاح.'},
    {keys:['فلتر','ترتيب','اقسام','بحث'], ans:'تقدر ترتّب الأحدث والأعلى/الأقل سعرًا وتحدد القسم ونطاق السعر من أيقونة الفلتر، أو تبحث باسم المنتج.'},
    {keys:['توصيل','شحن'], ans:'التوصيل ينفذّه الشريك. أحياناً مجاني للعميل حسب العرض. راجع خانة سعر التوصيل قبل تأكيد الطلب.'},
    {keys:['سعر','نطاق','ربح','اقل','اعلى'], ans:'خلي سعر الزبون ضمن النطاق الظاهر في صفحة المنتج. إذا الربح أقل من 10,000 د.ع عدّل السعر للأعلى.'},
    {keys:['دعم','تيكت','تذكرة','مشكلة'], ans:'افتح تبويب (الدعم) وسوّي تذكرة عامة أو مرتبطة بالطلب، وتابع المحادثة من نفس المكان.'},
  ];
  for(const it of intents){
    if(it.keys.some(k => q.includes(k))) return it.ans;
  }
  let best = null, score = 0;
  for(const item of state.kb){
    const s = sim(q, (item.q + ' ' + item.a).toLowerCase());
    if(s > score){ score = s; best = item; }
  }
  if(best && score > 0.12) return best.a;
  return 'أفهم سؤالك بس أحتاج توضيح بسيط. جرب تسأل عن: البدء بالبيع، تحديد السعر، التوصيل، السحب، الدعم، أو ترتيب المنتجات.';
}
function sim(a,b){
  const A = new Set(a.split(/\s+/).filter(Boolean));
  const B = new Set(b.split(/\s+/).filter(Boolean));
  const inter = new Set([...A].filter(x => B.has(x))).size;
  const uni = new Set([...A, ...B]).size;
  return inter / (uni || 1);
}
async function initChat(){
  await loadKB();
  const body = el('#chat-body');
  const input = el('#chat-input');
  const sendBtn = el('#send');
  function send(){
    const v = input.value.trim();
    if(!v) return;
    body.appendChild(createMsg(v, 'user'));
    input.value='';
    const ans = bestAnswer(v);
    body.appendChild(createMsg(ans, 'bot'));
    body.scrollTop = body.scrollHeight;
  }
  sendBtn.onclick = send;
  input.addEventListener('keydown', e=>{ if(e.key==='Enter'){ e.preventDefault(); send(); } });
  body.appendChild(createMsg('أهلًا بيك بدعم دروب فلاي 👋. اسألني عن أي شي يخص: إنشاء حساب، اختيار المنتجات، تسعير، التوصيل، سحب الأرباح، وتتبع الطلبات.'));
}
function toggleChat(){
  const box = el('#chat-box');
  if(box.style.display === 'none' || !box.style.display){ box.style.display='block'; if(!state.opened){ initChat(); state.opened=true; } }
  else{ box.style.display='none'; }
}
window.addEventListener('load', ()=>{
  el('#chat-toggle').addEventListener('click', toggleChat);
});
