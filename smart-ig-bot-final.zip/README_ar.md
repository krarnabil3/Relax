# 🚀 Smart IG Commerce Bot — FINAL
تاريخ: 2025-10-17

## تشغيل سريع
```bash
npm i
cp .env.sample .env
npm run start
```
لوحة الإدارة: `/admin/` — سجل دخول باستخدام ADMIN_USERNAME/ADMIN_PASSWORD من `.env`

## ربط Meta Webhook
- Callback URL: `https://YOUR-SERVICE/webhook`
- Verify Token: نفس `.env`
- فعّل Instagram Messaging + Page events.

## النشر
- ارفع الملفات إلى GitHub (هذا الأرشيف مهيأ).
- اربطه على Render كـ Web Service: Start Command = `npm run start`.
