import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import morgan from 'morgan';
import bodyParser from 'body-parser';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import path from 'path';
import { fileURLToPath } from 'url';

import { router as webhookRouter } from './src/routes/webhook.js';
import { router as apiRouter } from './src/routes/api.js';
import { router as catalogRouter } from './src/routes/catalog.js';
import { ensureSeed } from './src/db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(helmet());
app.use(cors());
app.use(morgan('tiny'));
app.use(bodyParser.json({ limit: '1mb' }));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());

app.use('/admin', express.static(path.join(__dirname, 'public', 'admin')));
app.get('/health', (_req, res) => res.status(200).send('ok'));
app.use('/catalog', catalogRouter);
app.use('/webhook', rateLimit({ windowMs: 60*1000, limit: 120 }), webhookRouter);
app.use('/api', apiRouter);
app.get('/', (_req, res) => res.redirect('/admin/'));

const PORT = process.env.PORT || 3000;
ensureSeed().then(() => {
  app.listen(PORT, () => console.log('IG Final up on :'+PORT));
});