
import axios from 'axios';
const GRAPH_BASE = 'https://graph.facebook.com/v19.0';
export async function sendText(pageAccessToken, recipientId, text){
  const url = `${GRAPH_BASE}/me/messages?access_token=${encodeURIComponent(pageAccessToken)}`;
  const payload = { messaging_type:'RESPONSE', recipient:{ id: recipientId }, message:{ text } };
  await axios.post(url, payload);
}
