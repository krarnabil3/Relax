
export function detectLang(text){ return /[\u0600-\u06FF]/.test(text||'') ? 'ar' : 'en'; }
export function applyTemplate(str, vars){ let t=str||''; for(const [k,v] of Object.entries(vars||{})){ t=t.replace(new RegExp('{{\\s*'+k+'\\s*}}','g'), String(v??'')); } return t; }
