
const HELLO = ["سلام","مرحبا","هلا","اهلا","السلام عليكم","hello","hi"];
const PRICE = ["سعر","بكم","كم","price"];
const ORDER = ["طلب","اطلب","اريد","order","buy"];
const SHIPPING = ["توصيل","شحن","delivery"];
const WARRANTY = ["ضمان","كفالة","warranty"];
const PAY = ["دفع","تحويل","payment","pay"];
export function classify(text){
  const t=(text||"").toLowerCase(); const has=a=>a.some(w=>t.includes(w));
  if(has(ORDER)) return 'order'; if(has(PRICE)) return 'price'; if(has(HELLO)) return 'hello'; if(has(SHIPPING)) return 'shipping'; if(has(WARRANTY)) return 'warranty'; if(has(PAY)) return 'pay';
  return 'fallback';
}
const PHONE=/(\+?\d{9,15})/;
const NAME_KEYS=["اسم","الاسم","name"];
const PRODUCT_KEYS=["منتج","سلعة","غرض","موديل","product"];
const ADDRESS_KEYS=["عنوان","منطقة","محلة","شارع","اقرب","بيت","زقاق","address"];
export function parseOrder(text){
  const res={name:"",phone:"",product:"",address:"",qty:1}; const t=text||"";
  const m=t.match(PHONE); if(m) res.phone=m[1];
  const qm=t.match(/\b(\d{1,2})\b/)||t.match(/x(\d{1,2})/i); if(qm) res.qty=parseInt(qm[1],10);
  function after(keys){ for(const k of keys){ const i=t.toLowerCase().indexOf(k.toLowerCase()); if(i!==-1){ const s=t.slice(i+k.length).split(/[\n\r\-،:,]/)[0].trim(); if(s) return s; } } return ""; }
  res.name=after(NAME_KEYS); res.product=after(PRODUCT_KEYS); res.address=after(ADDRESS_KEYS);
  if(!res.product){ const q2=t.match(/[«“"']([^"”»']{2,})[»”"']/); if(q2) res.product=q2[1]; }
  return res;
}
