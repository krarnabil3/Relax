
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.join(__dirname, '..', 'data.db');
export const db = new Database(dbPath);
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS categories ( id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL );
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, sku TEXT, category_id INTEGER, price REAL DEFAULT 0, stock INTEGER DEFAULT 0,
  image_url TEXT, aliases TEXT, is_active INTEGER DEFAULT 1, created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS faqs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT NOT NULL, answer TEXT NOT NULL, tags TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS templates ( id INTEGER PRIMARY KEY AUTOINCREMENT, tkey TEXT UNIQUE NOT NULL, lang TEXT DEFAULT 'ar', text TEXT NOT NULL, created_at TEXT DEFAULT (datetime('now')) );
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT, sender_id TEXT, customer_name TEXT, phone TEXT, address TEXT,
  product_id INTEGER, product_name TEXT, qty INTEGER DEFAULT 1, price REAL DEFAULT 0, promo_code TEXT, discount REAL DEFAULT 0,
  total REAL DEFAULT 0, status TEXT DEFAULT 'pending', created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS order_timeline ( id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER, action TEXT, note TEXT, created_at TEXT DEFAULT (datetime('now')) );
CREATE TABLE IF NOT EXISTS conversations ( id INTEGER PRIMARY KEY AUTOINCREMENT, sender_id TEXT, channel TEXT, direction TEXT, message TEXT, created_at TEXT DEFAULT (datetime('now')) );
CREATE TABLE IF NOT EXISTS shipping_zones ( id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price REAL NOT NULL, est_days TEXT );
CREATE TABLE IF NOT EXISTS promos ( id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, type TEXT NOT NULL, value REAL NOT NULL, active INTEGER DEFAULT 1 );
`);

const seedTemplates = [
  ['hello','ar','هلا بيك 👋 وياك دعم {{store}}. اكتب "سعر + اسم المنتج" أو اكتب "طلب" حتى نبدأ.'],
  ['hello','en','Hello 👋 this is {{store}} support. Type "price + product" or "order" to proceed.'],
  ['order_confirm','ar','تم تسجيل طلبك ✅\nالمنتج: {{product}}\nالهاتف: {{phone}}\nالعنوان: {{address}}\nالكمية: {{qty}}\nالإجمالي: {{total}} د.ع'],
  ['ask_product','ar','شنو اسم المنتج المطلوب؟ 🙏'],
  ['ask_phone','ar','انطيني رقم الموبايل للتأكيد 📱'],
  ['ask_address','ar','اكتب عنوان التسليم بالتفصيل (منطقة/محلة/شارع + أقرب نقطة) 🏠'],
  ['fallback','ar','مفهوم ✅ اكتب "طلب" لتثبيت طلب جديد أو اسأل عن التوصيل/الضمان/السعر.']
];
const seedFaqs = [
  ['التوصيل','🚚 التوصيل متوفر لكل المحافظات. داخل بغداد 24–48 ساعة، المحافظات 2–4 أيام.','توصيل,شحن'],
  ['الضمان','🛡️ ضمان فحص عند الاستلام + خدمة ما بعد البيع.','ضمان,كفالة'],
  ['الدفع','💳 الدفع عند الاستلام ونقبل تحويلات.','دفع,سعر']
];
const seedShipping = [['بغداد',5000,'1-2'],['المحافظات',8000,'2-4']];

export async function ensureSeed(){
  for(const [tkey,lang,text] of seedTemplates){ try{ db.prepare('INSERT OR IGNORE INTO templates (tkey, lang, text) VALUES (?, ?, ?)').run(tkey, lang, text);}catch{} }
  for(const [q,a,t] of seedFaqs){ try{ db.prepare('INSERT OR IGNORE INTO faqs (question, answer, tags) VALUES (?, ?, ?)').run(q,a,t);}catch{} }
  for(const [n,p,e] of seedShipping){ try{ db.prepare('INSERT OR IGNORE INTO shipping_zones (name, price, est_days) VALUES (?, ?, ?)').run(n,p,e);}catch{} }
  const username = process.env.ADMIN_USERNAME || 'admin'; const pass = process.env.ADMIN_PASSWORD || 'admin123';
  const exists = db.prepare('SELECT id FROM users WHERE username=?').get(username);
  if(!exists){ const hash = bcrypt.hashSync(pass, 10); db.prepare('INSERT INTO users (username, password_hash) VALUES (?, ?)').run(username, hash); }
}
export function t(key, lang='ar'){
  const row = db.prepare('SELECT text FROM templates WHERE tkey=? AND lang=?').get(key, lang) || db.prepare('SELECT text FROM templates WHERE tkey=?').get(key);
  return row?.text || '';
}
