
import express from 'express'; import { db } from '../db.js'; export const router = express.Router();
router.get('/products.json', (req,res)=>{ const rows=db.prepare('SELECT p.*, (SELECT name FROM categories c WHERE c.id=p.category_id) as category FROM products p WHERE p.is_active=1').all(); res.json(rows); });
