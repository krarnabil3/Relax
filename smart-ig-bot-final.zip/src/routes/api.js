
import express from 'express'; import { db } from '../db.js'; import { authRequired, login } from '../middleware/auth.js';
import { stringify } from 'csv-stringify/sync'; import { parse as csvParse } from 'csv-parse/sync'; import { sendText } from '../utils/graph.js';
export const router = express.Router();
router.post('/login', login);
router.get('/stats', authRequired, (req,res)=>{
  const orders=db.prepare('SELECT COUNT(*) c FROM orders').get().c;
  const pending=db.prepare("SELECT COUNT(*) c FROM orders WHERE status='pending'").get().c;
  const month=db.prepare("SELECT COUNT(*) c FROM orders WHERE date(created_at)>=date('now','-30 day')").get().c;
  const conv=db.prepare('SELECT COUNT(*) c FROM conversations').get().c; res.json({orders,pending,month,conversations:conv});
});
router.get('/products', authRequired, (req,res)=>{ res.json(db.prepare('SELECT * FROM products ORDER BY id DESC').all()); });
router.post('/products', authRequired, (req,res)=>{
  const { name, sku, category_id, price=0, stock=0, image_url='', aliases='', is_active=1 } = req.body||{};
  const info=db.prepare('INSERT INTO products (name, sku, category_id, price, stock, image_url, aliases, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
    .run(name, sku, category_id, price, stock, image_url, aliases, is_active?1:0); res.json({ id: info.lastInsertRowid });
});
router.put('/products/:id', authRequired, (req,res)=>{
  const { name, sku, category_id, price, stock, image_url, aliases, is_active } = req.body||{};
  db.prepare('UPDATE products SET name=?, sku=?, category_id=?, price=?, stock=?, image_url=?, aliases=?, is_active=? WHERE id=?')
    .run(name, sku, category_id, price, stock, image_url, aliases, is_active?1:0, req.params.id); res.json({ ok:true });
});
router.post('/products/import', authRequired, (req,res)=>{
  const rows=csvParse(req.body?.csv||'', { columns:true, skip_empty_lines:true });
  const stmt=db.prepare('INSERT INTO products (name, sku, category_id, price, stock, image_url, aliases, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'); let cnt=0;
  db.transaction(()=>{ for(const r of rows){ stmt.run(r.name, r.sku||null, r.category_id||null, Number(r.price||0), Number(r.stock||0), r.image_url||'', r.aliases||'', 1); cnt++; } })();
  res.json({ imported: cnt });
});
router.get('/faqs', authRequired, (req,res)=>{ res.json(db.prepare('SELECT * FROM faqs ORDER BY id DESC').all()); });
router.post('/faqs', authRequired, (req,res)=>{
  const { question, answer, tags='' } = req.body||{}; const info=db.prepare('INSERT INTO faqs (question, answer, tags) VALUES (?, ?, ?)').run(question, answer, tags);
  res.json({ id: info.lastInsertRowid });
});
router.get('/templates', authRequired, (req,res)=>{ res.json(db.prepare('SELECT * FROM templates ORDER BY id DESC').all()); });
router.post('/templates', authRequired, (req,res)=>{
  const { tkey, lang='ar', text } = req.body||{}; const info=db.prepare('INSERT INTO templates (tkey, lang, text) VALUES (?, ?, ?)').run(tkey, lang, text);
  res.json({ id: info.lastInsertRowid });
});
router.get('/orders', authRequired, (req,res)=>{ res.json(db.prepare('SELECT * FROM orders ORDER BY id DESC').all()); });
router.post('/orders', authRequired, (req,res)=>{
  const { source, sender_id, customer_name, phone, address, product_id, product_name, qty=1, price=0, promo_code, discount=0, total=0, status='pending' } = req.body||{};
  const info=db.prepare(`INSERT INTO orders (source, sender_id, customer_name, phone, address, product_id, product_name, qty, price, promo_code, discount, total, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(source, sender_id, customer_name, phone, address, product_id, product_name, qty, price, promo_code, discount, total, status);
  db.prepare('INSERT INTO order_timeline (order_id, action, note) VALUES (?, ?, ?)').run(info.lastInsertRowid,'create','created from admin'); res.json({ id: info.lastInsertRowid });
});
router.put('/orders/:id', authRequired, (req,res)=>{
  const { status } = req.body||{}; if(status){ db.prepare('UPDATE orders SET status=? WHERE id=?').run(status, req.params.id);
    db.prepare('INSERT INTO order_timeline (order_id, action, note) VALUES (?, ?, ?)').run(req.params.id,'status',status); } res.json({ ok:true });
});
router.get('/orders/:id/timeline', authRequired, (req,res)=>{ res.json(db.prepare('SELECT * FROM order_timeline WHERE order_id=? ORDER BY id ASC').all(req.params.id)); });
router.get('/conversations', authRequired, (req,res)=>{ res.json(db.prepare('SELECT * FROM conversations ORDER BY id DESC LIMIT 1000').all()); });
router.post('/reply', authRequired, async (req,res)=>{
  const { sender_id, text } = req.body||{}; if(!sender_id||!text) return res.status(400).json({ error:'MISSING' });
  await sendText(process.env.PAGE_ACCESS_TOKEN, sender_id, text);
  db.prepare('INSERT INTO conversations (sender_id, channel, direction, message) VALUES (?, ?, ?, ?)').run(sender_id,'instagram','outbound',text);
  res.json({ ok:true });
});
router.get('/shipping', authRequired, (req,res)=>{ res.json(db.prepare('SELECT * FROM shipping_zones ORDER BY id ASC').all()); });
router.post('/shipping', authRequired, (req,res)=>{
  const { name, price, est_days } = req.body||{}; const info=db.prepare('INSERT INTO shipping_zones (name, price, est_days) VALUES (?, ?, ?)').run(name, price, est_days);
  res.json({ id: info.lastInsertRowid });
});
router.get('/promos', authRequired, (req,res)=>{ res.json(db.prepare('SELECT * FROM promos ORDER BY id DESC').all()); });
router.post('/promos', authRequired, (req,res)=>{
  const { code, type, value, active=1 } = req.body||{}; const info=db.prepare('INSERT INTO promos (code, type, value, active) VALUES (?, ?, ?, ?)').run(code, type, value, active?1:0);
  res.json({ id: info.lastInsertRowid });
});
router.get('/export/orders.csv', authRequired, (req,res)=>{
  const rows=db.prepare('SELECT * FROM orders ORDER BY id DESC').all(); const csv=stringify(rows, { header:true });
  res.setHeader('Content-Type','text/csv; charset=utf-8'); res.setHeader('Content-Disposition','attachment; filename="orders.csv"'); res.send(csv);
});
