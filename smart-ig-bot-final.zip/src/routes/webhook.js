
import express from 'express'; import crypto from 'crypto'; import { db, t } from '../db.js'; import { classify, parseOrder } from '../utils/nlp.js';
import { sendText } from '../utils/graph.js'; import { notifyTelegram } from '../utils/notify.js'; import { detectLang, applyTemplate } from '../utils/common.js';
export const router = express.Router();
router.get('/', (req,res)=>{ const mode=req.query['hub.mode'], token=req.query['hub.verify_token'], challenge=req.query['hub.challenge'];
  if(mode==='subscribe' && token===process.env.VERIFY_TOKEN) return res.status(200).send(challenge); return res.sendStatus(403); });
router.post('/', express.json({ verify: verifySignature }), async (req,res)=>{
  const body=req.body; if(body.object!=='instagram' && body.object!=='page') return res.sendStatus(404);
  try{ for(const entry of body.entry||[]){ const events = entry.messaging || (entry.changes?.flatMap(c=>c?.value?.messaging||[])||[]);
    for(const ev of events){ await processEvent(ev); } } }catch(e){ console.error('webhook error', e); } res.sendStatus(200);
});
function verifySignature(req,res,buf){ const signature=req.get('x-hub-signature-256'); const secret=process.env.APP_SECRET; if(!secret||!signature) return;
  const expected='sha256='+crypto.createHmac('sha256', secret).update(buf).digest('hex'); if(signature!==expected) throw new Error('Invalid request signature'); }
async function processEvent(event){
  const senderId=event.sender?.id; const text=event.message?.text || event.message?.message || ''; if(!senderId||!text) return;
  db.prepare('INSERT INTO conversations (sender_id, channel, direction, message) VALUES (?, ?, ?, ?)').run(senderId,'instagram','inbound',text);
  const lang=detectLang(text); const token=process.env.PAGE_ACCESS_TOKEN; const store=process.env.DEFAULT_STORE_NAME||'المتجر'; const intent=classify(text);
  if(intent==='hello'){ await sendText(token, senderId, applyTemplate(t('hello',lang), { store })); return; }
  if(intent==='price'){ const q=text.replace(/سعر|price|بكم|كم/gi,'').trim();
    const row=db.prepare(`SELECT name,price,stock FROM products WHERE is_active=1 AND (name LIKE ? OR instr(aliases, ?) > 0) ORDER BY id DESC`).get(`%${q}%`, q);
    if(row){ await sendText(token, senderId, lang==='ar'?`السعر الحالي لمنتج "${row.name}" هو ${row.price} د.ع. المتوفر: ${row.stock}.`:`Current price for "${row.name}" is ${row.price} IQD. In stock: ${row.stock}.`); return; }
    await sendText(token, senderId, lang==='ar'?'📦 اكتب اسم المنتج حتى نرجعلك بالسعر.':'📦 Tell me the product name for the price.'); return; }
  if(intent==='order'){ const o=parseOrder(text); if(!o.product){ await sendText(token, senderId, t('ask_product','ar')); return; }
    if(!o.phone){ await sendText(token, senderId, t('ask_phone','ar')); return; }
    if(!o.address){ await sendText(token, senderId, t('ask_address','ar')); return; }
    const prod=db.prepare(`SELECT id,name,price,stock FROM products WHERE is_active=1 AND (name LIKE ? OR instr(aliases, ?) > 0) ORDER BY id DESC`).get(`%${o.product}%`, o.product);
    const price=prod?.price||0; const isBaghdad=/بغداد|baghdad/i.test(o.address||''); const ship=db.prepare('SELECT price FROM shipping_zones WHERE name=?').get(isBaghdad?'بغداد':'المحافظات')?.price||0;
    const promoMatch=(text||'').match(/promo\s*:?\s*([A-Z0-9-_]+)/i) || (text||'').match(/كود\s*:?\s*([A-Za-z0-9-_]+)/); let discount=0, promo_code='';
    if(promoMatch){ promo_code=promoMatch[1].toUpperCase(); const pr=db.prepare('SELECT * FROM promos WHERE code=? AND active=1').get(promo_code);
      if(pr){ discount=pr.type==='percent'?(price*o.qty)*pr.value/100:pr.value; } }
    const subtotal=price*o.qty; const total=Math.max(0, subtotal+ship-discount);
    const info=db.prepare(`INSERT INTO orders (source, sender_id, customer_name, phone, address, product_id, product_name, qty, price, promo_code, discount, total, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run('instagram', senderId, o.name, o.phone, o.address, prod?.id||null, prod?.name||o.product, o.qty, price, promo_code, discount, total, 'pending');
    db.prepare('INSERT INTO order_timeline (order_id, action, note) VALUES (?, ?, ?)').run(info.lastInsertRowid,'create','created via DM');
    if(prod?.id){ db.prepare('UPDATE products SET stock = MAX(stock - ?, 0) WHERE id=?').run(o.qty, prod.id); }
    const confirm=applyTemplate(t('order_confirm','ar'), { product:(prod?.name||o.product), phone:o.phone, address:o.address, qty:o.qty, total });
    await sendText(token, senderId, confirm); notifyTelegram(`طلب جديد #${info.lastInsertRowid} - ${(prod?.name||o.product)} x${o.qty} - ${total} IQD`).catch(()=>{}); return; }
  const faq=db.prepare(`SELECT answer FROM faqs WHERE instr(lower(tags||','||question), lower(?)) > 0 ORDER BY id DESC`).get(text);
  if(faq){ await sendText(token, senderId, faq.answer); return; } await sendText(token, senderId, t('fallback','ar'));
}
