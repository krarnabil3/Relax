
import jwt from 'jsonwebtoken'; import bcrypt from 'bcryptjs'; import { db } from '../db.js';
export function signToken(user){ const secret=process.env.JWT_SECRET||'secret'; return jwt.sign({id:user.id,username:user.username}, secret, {expiresIn:'7d'}); }
export function authRequired(req,res,next){
  const auth=req.headers.authorization||''; const token=auth.startsWith('Bearer ')?auth.slice(7):null; if(!token) return res.status(401).json({error:'UNAUTHORIZED'});
  try{ req.user=jwt.verify(token, process.env.JWT_SECRET||'secret'); next(); }catch(e){ return res.status(401).json({error:'INVALID_TOKEN'}); }
}
export function login(req,res){
  const {username,password}=req.body||{}; if(!username||!password) return res.status(400).json({error:'MISSING'});
  const row=db.prepare('SELECT * FROM users WHERE username=?').get(username); if(!row) return res.status(401).json({error:'BAD_CREDENTIALS'});
  if(!bcrypt.compareSync(password, row.password_hash)) return res.status(401).json({error:'BAD_CREDENTIALS'});
  const token=signToken(row); return res.json({token, username: row.username});
}
